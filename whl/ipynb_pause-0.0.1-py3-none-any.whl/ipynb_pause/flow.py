# Code to support widgets with Input to Advance
#Define thread that allows killing
import threading
import trace
import asyncio
import time
import sys
import ipywidgets as widgets
from jupyter_ui_poll import run_ui_poll_loop, ui_events, with_ui_events

#Create a thread class with the ability to kill
class thread_with_kill(threading.Thread):
    def __init__(self, *args, **keywords):
        threading.Thread.__init__(self, *args, **keywords)
        self.killed = False
 
    def start(self):
        self.__run_backup = self.run
        self.run = self.__run      
        threading.Thread.start(self)
 
    def __run(self):
        sys.settrace(self.globaltrace)
        self.__run_backup()
        self.run = self.__run_backup
 
    def globaltrace(self, frame, event, arg):
        if event == 'call':
            return self.localtrace
        else:
            return None
 
    def localtrace(self, frame, event, arg):
        if self.killed:
            if event == 'line':
                raise SystemExit()
        return self.localtrace
 
    def kill(self):
        self.killed = True
        
#Create a reading method that is used to move the focus to the current code       
def reading():
    input()        

#Action on clicking button        
def on_click(btn):
     btn.description = "Running"
        
# Create a clsss to keep the state of the display mode, the default position and the output stream
class display_mode:
    def __init__(self, mode=False, position="both", output=None, color=None):
        self.dual=mode
        self.position=position
        self.out_io=output
        self.color=color

    #Create the waiting function to wait on selecton button and to kill input            
    def pause(self, location=None):
        if location is None:
            location=self.position
        if not self.dual:
            return
        self.dual = True
        self.position = "both"
        t1 = thread_with_kill(target = reading)
        t1.start()          #Start Input thread to pull focus to current code cell
        time.sleep(0.1)
        t1.kill()
        btn = widgets.Button(description="Continue")
        if self.color is not None:
            btn.style.button_color = self.color
        btn.on_click(on_click)
        display(btn)
        with self.out_io:
            display(btn)
        with ui_events() as ui_poll:
            while btn.description == "Continue":
                ui_poll(11) 
                time.sleep(0.1)       
        with self.out_io: 
            self.out_io.clear_output()

    def resume(self):
        if not self.dual:
            return
        with self.out_io:
            display(widgets.HTML("<p style='font-family:IBM Plex Sans;font-size:24px'>Demo Complete"))
        input("Demo Complete")